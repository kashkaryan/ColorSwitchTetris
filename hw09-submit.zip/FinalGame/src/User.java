public class User implements Comparable<User> {

	private String nickname;
	private final int ident; //calling their score their ident
	
	public User(String n, int num) {
		setNickname(n);
		ident = num;
	}

	public String getNickname() {
		return nickname;
	}

	//Don't allow numbers or special characters, get rid of it and add name
	public void setNickname(String nickname) {
	   String userName = "";
 	   char[] a = nickname.toCharArray();
 	   for (int i = 0; i < a.length; i++) {
 		   if (Character.isLetter(a[i])) {
 			   userName += a[i];
 		   }
 	   }
		this.nickname = userName;
	}

	public int getIdent() {
		return ident;
	}

	//Compare by their score 
	@Override
	public int compareTo(User o) {
		if (this.ident == o.ident) {
			return 0;
		} else if (this.ident > o.ident) {
			return -1;
		} else {
			return 1;
		}
	}
	
	//check if equals for testing, make it simple and ask if same ident
	@Override
	public boolean equals(Object o) {
		boolean answer = false;
		User s = (User) o;
		if (this.ident == s.ident) {
			answer = true;
		}
		return answer;
	}
}

