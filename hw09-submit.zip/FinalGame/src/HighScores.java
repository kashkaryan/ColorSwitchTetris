import java.awt.BorderLayout;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Scanner;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HighScores {
	
	private static List<User> setUser; //Can have duplicates, just want order
	
	public HighScores() {
		setUser = new LinkedList<User>(); //static type is interface

	}
	
	public void addUser(User e) {
		inpToFile(e, "files/output.txt"); //where user is printed
	}
	
	public static void highScore() throws IOException {
		outputHigh(new File ("files/output.txt")); //add users in file to collection
		final JFrame frameHigh = new JFrame("High Scores"); //open new frame
			 
    	JLabel lblFName = new JLabel("<html> <h1 align='center'> Top 5 Scores </h1>");
    	JLabel lblFScores = new JLabel();
    	Collection<User> c = setUser;
    	String toAdd = "";
    	int count = 1;
    	//go through setUser, and add top 5
    	try {
        	Iterator<User> iter = c.iterator();
    		while (iter.hasNext() && count < 6) {
    		User user1 = iter.next();
    		toAdd = toAdd + ("<html> <h2 align='center'> " + count + ". " + 
    		user1.getNickname() + "-----" + user1.getIdent() + "\n" + " </h2>");
    		count++;
    		}
    	} catch (NullPointerException e) {
    		toAdd = "No Players Yet"; //Empty File
    	}
    	
    	lblFScores.setText(toAdd);
    	
    	JPanel panel = new JPanel();
    	panel.setLayout(new BorderLayout());
    
    	panel.add(lblFName, BorderLayout.NORTH);
    	panel.add(lblFScores, BorderLayout.CENTER);
    	
    	 
    	frameHigh.setLocationRelativeTo(Game.getFrame());
    	frameHigh.setSize(300, 300);
    	frameHigh.getContentPane().add(panel);
    	frameHigh.setVisible(true);
    	
    	
	}
	
	public static void outputHigh(File in) throws IOException {
		setUser.clear(); //So it doesn't duplicate
        Scanner read = new Scanner (in);
        //add each line as User to setUser
        while (read.hasNext()) {
        	String a = read.nextLine();
        	String name = "";
        	String num = "";
        	char[] charA = a.toCharArray();
        	for (int i = 0; i < charA.length; i ++ ) {
        		if (Character.isLetter(charA[i])) {
        			name = name + charA[i];
        		} else if (Character.isDigit(charA[i])) {
        			num = num + charA[i];
        		}
        	}
        	int number = Integer.parseInt(num);
        	User u = new  User (name, number);
        	setUser.add(u);
    		Collections.sort(setUser); //sort by descending order
        }
        read.close();
        //check if input number is one of the numbers given
    }
	
	public static void inpToFile (User u, String c) {
		//add new User to the file, printed like nameScore
		try {
			BufferedWriter fileout;
			String name = u.getNickname();
			String score = "" + u.getIdent();
			fileout = new BufferedWriter(new FileWriter(c, true));
			fileout.append(name + score);
			fileout.newLine();
			fileout.close();
		} catch (IOException e) {
		}
	}
	
	// For testing
	public void addUserStraight(User a) {
		setUser.add(a);
	}
	
	public User getFirst() {
		return setUser.get(0);
	}
	
	public User getSecond() {
		return setUser.get(1);
	}
	
	public void clear() {
		setUser.clear();
	}
}
