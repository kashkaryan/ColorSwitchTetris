import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

import javax.swing.*;

public class Game {

	private static JFrame frame;
	public static final int WIDTH = 460;
	public static final int HEIGHT = 660;
	int score = 0;
	
	public Game() {
		frame = new JFrame ("Tetris");
        frame.setLocationRelativeTo(null);
		frame.setSize(WIDTH,HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
		MainTetris play = new MainTetris();
		score = play.getScore();
		play.setBounds(0,25,WIDTH,HEIGHT- 25);
		JMenuBar men = new JMenuBar();
		men.setBounds(0, 0, WIDTH, 25);
        
        JButton newGame = new JButton("New Game");
        newGame.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		play.newGame();
        	}
        });
        
        JButton info = new JButton("How To Play");
        info.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		JFrame open = new JFrame("Tutorial");
        		open.setVisible(true);
        		open.setSize(WIDTH, HEIGHT);
                open.setLocationRelativeTo(frame);
                open.setResizable(false);
        		JLabel inform = new JLabel("Tutorial", JLabel.CENTER);

        		inform.setLayout(null);
        		inform.setSize(WIDTH - 25, HEIGHT - 25);
                inform.setText("<html> <h1 align='center'> What is Tetris </h1>"
                		+ " To play Tetris, you must clear lines by "
                		+ "rotating and moving shapes to fill every square"
                		+ " in a horixontal row to clear it as they are "
                		+ "generated. Colors are switched with each new shape "
                		+ "to make the game more difficult to follow. \n "
                		+ "<html> <h1 align='center'> Controls </h1>"
                		+ "The up arrow key rotates the shape counter-"
                		+ "clockwise, the left and right arrows move shapes "
                		+ "latterly, and the down arrow sends the shape "
                		+ "down quicker. Press space to go back to the "
                		+ "previous step, before you put down a shape. It also "
                		+ " replaces the next shape down to a random one.\n"
                		+ "<b>Exit tutorial after reading instructions to"
                		+ " play.<b>\n \n"
                		+ "<h1 style=\"color: blue;\"> Good Luck! </h1>");
        		inform.setVisible(true);
        		open.add(inform, BorderLayout.NORTH);
        	}
        });
        
        JButton scores = new JButton("High Scores");
        scores.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		try {
					HighScores.highScore();
				} catch (IOException e1) { //do nothing
				}
        	}
        });

        
        men.add(newGame);
        men.add(info);
        men.add(scores);
        frame.add(men, BorderLayout.NORTH);
        frame.add(play, BorderLayout.CENTER);
        frame.setVisible(true);
        
	}
	
	public static JFrame getFrame() {
		return frame;
	}

	public static void main(String [] args) {
		new Game();
	}
	
}
