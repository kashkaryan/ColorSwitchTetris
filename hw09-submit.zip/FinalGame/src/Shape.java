import java.awt.Color;
import java.awt.Graphics;

public class Shape {

	//encapsulate
	private SingleSq box;
	private int[][] coord;
	private MainTetris court;
	private final int SIZE = 30;
	private int moveX = 0;
	private int x;
	private int y;
	private long finish;
	private long start;
	private int norm = 650, fast = 65, curr;
	private boolean hit = false, lateral = false;
	
	
	public Shape(SingleSq box, int[][] coord, MainTetris court) {
		this.box = box;
		this.coord = coord;
		this.court = court;
		finish = 0; //start with finish at 0
		curr = norm;
		//if you start with 0, updates first jump too quickly
		start = System.currentTimeMillis(); //start with time from beginning
		
		x = 3;
		y = 0;
		speedWithTime(); //speed up with score
	}
	
	public void update() {
		//start not moving, then add difference from past time
		//first time it updates, finish is 0, then it increases as start goes through
		//and updates to new value that is less than the end time
		long end = System.currentTimeMillis();
		finish += end  - start; //duration
		start = System.currentTimeMillis(); //set to new start time for next update
		
		if (isHit()) { //run through entire court, then put one in shape if filled
			for (int i = 0; i < coord.length; i++) {
				for (int j = 0; j < coord[0].length; j++) {
					if(coord[i][j] != 0) {
						court.getCourt()[y + i][x + j] = 1;
					}
				}
			}
			check(); //if filled line, delete
			court.makeNew(); //add new shape
		}
		
		if (!(x + moveX < 0) && !(x + moveX + coord[0].length > 10) 
				&& y + coord.length != 20) {
			
			for (int i = 0; i < coord.length; i ++) {
				for (int j = 0; j < coord[i].length; j++) {
					if (coord[i][j] == 1) {
						if (court.getCourt()[y + i][x + j + moveX] == 1) {
							lateral = true;
						}
					}
				}
			}
			if (!lateral) { //if not blocked laterally, move x and reset change in x
				x += moveX;
				moveX = 0;
			}
		}
		
		if (!(y + 1 + coord.length > 20)) { //hit shape that is already set on map
			  
			for (int i = 0; i < coord.length; i ++) {
				for (int j = 0; j < coord[i].length; j++) {
					if (coord[i][j] == 1) {
						if (court.getCourt()[y + 1 + i][x + j] == 1) {
							setHit(true);
						}
					}
				}
			}
			if (finish > curr) { //moves when it updates every curr amount of times
				y++; //drop one after alloted time
				finish = 0; //reset time after drops
			}
		} else { //hit floor of map
			setHit(true);
		} //reset moveX and lateral as shape is moved down and updated
		moveX = 0;
		lateral = false;
	}
	
	//draw each box as filled rectangle
	public void draw(Graphics g) {
		g.setColor(box.getColor());
		for (int i = 0; i < coord.length; i++) {
			for (int j = 0; j < coord[i].length; j++) {
				if (coord[i][j] != 0) 
					g.fillRect(j * SIZE + x * SIZE,
							i * SIZE + y * SIZE, SIZE, SIZE);		
			}
		}
	}
	
	//flip coordinates left right, then up down for counter-clockwise
	public void rotate(){
		if (isHit()) return;
		int[][] old = coord;
		int row = old.length;
		int col = old[0].length;  
		int[][] newCoord = new int[col][row];
		boolean canRotate = true;
		  
		for (int i = 0; i < row; i++) {
			  for (int j = 0; j < col; j++) {
				 int temp = old[i][j];
				 newCoord[newCoord.length - j - 1][i] = temp;
			  }
		}
		  //can't rotate if the new coordinates won't let it rotate on right edge or bottom
		  if (x + newCoord[0].length > 10 || y + newCoord.length > 20) {
			  return;
		  }
		  
		  //can't rotate if set shape is in the way
		  for (int i = 0; i < newCoord.length; i ++) {
				for (int j = 0; j < newCoord[i].length; j++) {
					if (newCoord[i][j] == 1) {
						if (court.getCourt()[y + i][x + j] == 1) {
							canRotate = false;
						}
					}
				}
			}
		  
		  if (!canRotate) return;
		  
		  //if it's able to rotate, flip new coordinates 
		  coord = newCoord;
	  }
	
	public void setMoveX (int move) {
		this.moveX = move;
	}
	
	public void fastDown () {
		curr = fast;
	}
	
	public void normDown () {
		curr = norm;
	}

	public SingleSq getBox() {
		return box;
	}

	public int[][] getCoord() {
		return coord;
	}
	
	public Color getColor() {
		return box.getColor();
	}
	
	public void check() {
		//checks if line is filled after shape is hit, and add to score
		for (int row = 0; row < court.getCourt().length; row++) {
		    boolean isFilled = true;
		    for (int col = 0; col < court.getCourt()[row].length; col++) {
		        if (court.getCourt()[row][col] == 0) {
		            isFilled = false;
		        }
		    }
		    if (isFilled) {
		    	deleteLine(row);
		    	int old = court.getScore();
		    	court.setScore(old + 100);
		    }
		}
	}
	
	//erase line and move down all blocks before it 
	public void deleteLine(int line) {
		for (int i = line; i > 0; i--) {
			for (int j = 0; j < court.getCourt()[0].length; j++) {
				court.getCourt()[i][j] = court.getCourt()[i - 1][j];
			}
		}
	}
	
	//increment time as score is increased
	public void speedWithTime() {
		int a = court.getScore();
			if (a > 500) {
				norm = 550;
			} else if (a > 1000) {
				norm = 500;
			}else if (a > 2000) {
				norm = 450;
			} else if (a > 3000) {
				norm = 350;
			} else if (a > 4000) {
				norm = 250;
			} else if (a > 5000) {
				norm = 150;
			} else if (a > 6000) {
				norm = 100;
			}
		}

	public boolean isHit() {
		return hit;
	}

	public void setHit(boolean hit) {
		this.hit = hit;
	}
}
