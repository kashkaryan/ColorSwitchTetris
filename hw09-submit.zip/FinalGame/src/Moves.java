import java.util.LinkedList;
import java.util.List;

public class Moves {
	
private List<int[][]> move;

	public Moves() {
		move = new LinkedList<int[][]>();
	}
	
	public void addMove (int[][] movesArr) {
		 move.add(movesArr);
	}
	
	public int[][] delMove () {
		return move.remove(move.size() - 1); //return deleted move
	}
	
	public void clearMove () {
		move.clear();
	}
	
	public int size() {
		return move.size();
	}
	
	public int[][] getRecent() {
		return move.get(move.size() - 1);
	}
	
	//for testing
	public int[][] getFirst() {
		return move.get(0);
	}
}
