
	import java.awt.*;

	/**
	 * Represents a single block of the shape
	 */
	public class SingleSq {
	    public static final int SIZE = 30;
	    private Color color;

	    /**
	    * Only care about the box and how to draw it
	    */
	    
	    public SingleSq(Color color) {
	    	this.color = color;
	    }
	    
	    public Color getColor() {
	    	return color;
	    }

	    public void draw(Graphics g) {
	        g.setColor(this.color);
	        g.fillRect(0, 0, SIZE, SIZE);
	    }
	}
