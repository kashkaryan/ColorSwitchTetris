import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

public class MainTetris extends JPanel {

	private final int indSize = 30;
	private final int arrayW = 10;
	private final int arrayH = 20;
	private int[][] court = new int[arrayH][arrayW];
	private Shape[] diffShapes = new Shape[7];
	public Shape nextShape; //access when testing, to set
	private int score;
    public static final int INTERVAL = 35;
    boolean gameOver = false;
    private Timer timer;
	private boolean firstGame = true;
  	public HighScores highS; //access during testing
  	private Moves move = new Moves();

	public MainTetris() {
		
		highS = new HighScores();
		//action every interval, then use helper function tick to do everything that
		//should be done in a single step
        timer = new Timer(INTERVAL, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tick();
            }
        });
        
        timer.start();
        
        setFocusable(true); //to know that the keys are sent to MainTetris
		
		addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    nextShape.setMoveX(-1);
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                	nextShape.setMoveX(1);
                } else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                	nextShape.fastDown();
                } else if (e.getKeyCode() == KeyEvent.VK_UP) {
                	nextShape.rotate();
                } else if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                	try { 
	                	court = move.delMove();
	                	makeNew();
                	} catch (IndexOutOfBoundsException err) {
        			 System.out.println("No moves to undo."); //Try to undo no moves
        		 }
                }
            }

            public void keyReleased(KeyEvent e) {
            	if (e.getKeyCode() == KeyEvent.VK_DOWN) {
            		nextShape.normDown();
            	}
            }
		});
		
		diffShapes[0] = new Shape(new SingleSq(Color.red), new int[][] {
			{1, 1, 1, 1}
		}, this);
	
		diffShapes[1] = new Shape(new SingleSq(Color.orange), new int[][] {
			{1, 1, 0},
			{0, 1, 1}
		}, this);
		
		diffShapes[2] = new Shape(new SingleSq(Color.yellow), new int[][] {
			{0, 1, 1},
			{1, 1, 0}
		}, this);
		
		diffShapes[3] = new Shape(new SingleSq(Color.cyan), new int[][] {
			{1, 1, 1},
			{0, 1, 0}
		}, this);
		
		diffShapes[4] = new Shape(new SingleSq(Color.blue), new int[][] {
			{1, 1, 1},
			{0, 0, 1}
		}, this);
		
		diffShapes[5] = new Shape(new SingleSq(Color.magenta), new int[][] {
			{1, 1, 1},
			{1, 0, 0}
		}, this);
		
		diffShapes[6] = new Shape(new SingleSq(Color.green), new int[][] {
			{1, 1},
			{1, 1}
		}, this);
		
		makeNew(); //Make new shape and check if game is over
    }
	
	public void makeNew() {
		int index = (int)(Math.random() * 7); //choose random shape, set to next
		Shape next = new Shape (diffShapes[index].getBox(), 
				diffShapes[index].getCoord(), this);
		if (!gameOver) 
			nextShape = next; //drop new one
			gameOver();
		if (gameOver) {
			move.clearMove(); //list of moves are reset, take down User name
			final JFrame frameHigh = new JFrame("Enter Valid Name for High Score");
			 
        	JLabel lblFName = new JLabel("(No Numbers or Special Characters) Name:");
        	JTextField tfFName = new JTextField(20);
        	lblFName.setLabelFor(tfFName);
 
        	JPanel panel = new JPanel();
        	panel.setLayout(new BorderLayout());
        	
        	JButton enterButton = new JButton("Enter");
            enterButton.addActionListener(new ActionListener() {
               public void actionPerformed(ActionEvent e) {  
       			String userName = "";
            	   char[] a = tfFName.getText().toCharArray();
            	   for (int i = 0; i < a.length; i++) {
            		   if (Character.isLetter(a[i])) {
            			   userName += a[i];
            		   }
            	   }
               	 User user = new User(userName, score);
               	 highS.addUser(user);
               	 frameHigh.dispose();
               }
            }); 
        
        	panel.add(lblFName, BorderLayout.NORTH);
        	panel.add(tfFName, BorderLayout.CENTER);
        	panel.add(enterButton, BorderLayout.SOUTH);
 
        	frameHigh.setLocationRelativeTo(Game.getFrame());
        	frameHigh.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        	frameHigh.setSize(300, 100);
        	frameHigh.getContentPane().add(panel);
        	frameHigh.setVisible(true);
		}
	}
	
	public int[][] getCourt() {
		return court;
	}
	
	//overrides repaint in tick
	  @Override
	    public void paintComponent(Graphics g) {
		  if(!firstGame && nextShape.isHit())addMoves(); //add new Move after block hit
		  if (!firstGame) {
	        super.paintComponent(g);
	        nextShape.draw(g); //draw shape coming down
	        
	        //repaint court, in color of nextShape, for color switch
			for(int row = 0; row < court.length; row++) {
				for(int col = 0; col < court[row].length; col++) {
					if(court[row][col] == 1) {
						g.fillRect(col * indSize, row * indSize, indSize, indSize);
					}
				}
			}
			
	        g.setColor(Color.black);
	        //draw court using 2D array
	        
	        for (int i = 0; i < arrayH + 1; i++) {
	        	g.drawLine(0, i* indSize, arrayW*indSize, i*indSize);
	        }
	        
	        for (int i = 0; i <= arrayW; i++) {
	        	g.drawLine(i * indSize, 0, i * indSize, arrayH * indSize);
	        }
	        
	        //keep score
	        g.drawString("SCORE", Game.WIDTH - 125, Game.HEIGHT/5);
			g.drawString("" + score, Game.WIDTH - 125, Game.HEIGHT/5 + 30);
			
			if (gameOver) { //notify User they lost
				String gameOverString = "GAME OVER";
				g.setColor(Color.BLACK);
				g.setFont(new Font("Georgia", Font.BOLD, 30));
				g.drawString(gameOverString, 50, Game.HEIGHT/2);
			}
		  } else { //First thing seen, give quick instructions
			  String gameStart = "PRESS NEW GAME TO BEGIN";
			  String gameInfo = "PRESS HOW TO PLAY FOR INFORMATION";
			  String gameBest = "PRESS HIGH SCORE FOR LEADERBOARD";
			  g.setColor(Color.BLACK);
			  g.setFont(new Font("Georgia", Font.BOLD, 25));
			  g.drawString(gameStart, 40, 1 * Game.HEIGHT/5);
			  g.setFont(new Font("Georgia", Font.BOLD, 20));
			  g.drawString(gameInfo, 10, 2 * Game.HEIGHT/5);
			  g.drawString(gameBest, 15, 3 * Game.HEIGHT/5);
		  }
	  	}
		
		public void tick() {
			
			nextShape.update(); //move shape down
			repaint(); //draw every interval
	        requestFocusInWindow(); //need this here for keyboard
		}
		
		public void setScore(int a){
			this.score = a;
		}
		
		public int getScore(){
			return score;
		}
		
		public void newGame() { //clear map, clear moves, start timer over
			firstGame = false;
			score = 0;
			for (int i = 0; i < court.length; i ++) {
				for (int j = 0; j< court[0].length; j++) {
					court[i][j] = 0;
				}
			}
			gameOver = false;
			makeNew();
			timer.restart();
			move.clearMove();
		}
		
		public void gameOver() { //stop game when a column is full
			for (int col = 0; col < court[0].length; col++) {
				if (court[0][col] != 0 ) {
					gameOver = true;
					timer.stop();
				}
			}
		}
		
		public boolean getGameOver() {
			return gameOver;
		}
		
		public void addMoves() { //add image of map using temp variable add
			int[][] add = new int [arrayH][arrayW];
			for (int i = 0; i < court.length; i ++) {
				for (int j = 0; j< court[0].length; j++) {
					add[i][j] = court[i][j];
				}
			}
			move.addMove(add);
		}
		
		//for testing
	  	public Shape[] getDiffShapes() {
			return diffShapes;
	  	}
	  	
		public Moves getMove() {
			return move;
		}
		
		public void setCourt(int[][] a) {
			court = a;
		}
}
