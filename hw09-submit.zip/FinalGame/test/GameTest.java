import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

import org.junit.Before;
import org.junit.Test;

/** 
 *  You can use this file (and others) to test your
 *  implementation.
 */

public class GameTest {

	private MainTetris tm;

    @Before
    public void setUp() {
        tm = new MainTetris();
    }

    @Test
    public void testAllShapes() {

        Shape line = new Shape (tm.getDiffShapes()[0].getBox(), 
        		tm.getDiffShapes()[0].getCoord(), tm);
        int actualLineL = line.getCoord()[0].length;
        assertEquals("Length is 4", 4, actualLineL);
        int actualLineW = line.getCoord().length;
        assertEquals("Width is 1", 1, actualLineW);
        
        Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
        		tm.getDiffShapes()[1].getCoord(), tm);
        int actualZigL = zig.getCoord()[0].length;
        assertEquals("Length is 3", 3, actualZigL);
        int actualZigW = zig.getCoord().length;
        assertEquals("Width is 2", 2, actualZigW);
        
        Shape square = new Shape (tm.getDiffShapes()[6].getBox(), 
        		tm.getDiffShapes()[6].getCoord(), tm);
        int actualSquareL = square.getCoord()[0].length;
        assertEquals("Length is 2", 2, actualSquareL);
        int actualSquareW = square.getCoord().length;
        assertEquals("Width is 2", 2, actualSquareW);
    }
    
    @Test
    public void testAllShapesRotate() {
    	Shape line = new Shape (tm.getDiffShapes()[0].getBox(), 
        		tm.getDiffShapes()[0].getCoord(), tm);
    	line.rotate();
        int actualLineL = line.getCoord()[0].length;
        assertEquals("Length is 1", 1, actualLineL);
        int actualLineW = line.getCoord().length;
        assertEquals("Width is 4", 4, actualLineW);
        
        Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
        		tm.getDiffShapes()[1].getCoord(), tm);
        zig.rotate();
        int actualZigL = zig.getCoord()[0].length;
        assertEquals("Length is 2", 2, actualZigL);
        int actualZigW = zig.getCoord().length;
        assertEquals("Width is 3", 3, actualZigW);
        
        Shape square = new Shape (tm.getDiffShapes()[6].getBox(), 
        		tm.getDiffShapes()[6].getCoord(), tm);
        square.rotate();
        int actualSquareL = square.getCoord()[0].length;
        assertEquals("Length is 2", 2, actualSquareL);
        int actualSquareW = square.getCoord().length;
        assertEquals("Width is 2", 2, actualSquareW);
    }
    
    @Test
    public void testRotateNotAbleRight() {
    	 Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
         zig.rotate();
         tm.nextShape = zig;
         tm.nextShape.setMoveX(5);
         tm.nextShape.update();
         tm.nextShape.rotate();
         int actualZigL = tm.nextShape.getCoord()[0].length;
         assertEquals("Length is 2", 2, actualZigL);
         int actualZigW = tm.nextShape.getCoord().length;
         assertEquals("Width is 3", 3, actualZigW);
         
         Shape line = new Shape (tm.getDiffShapes()[0].getBox(), 
          		tm.getDiffShapes()[0].getCoord(), tm);
          line.rotate();
          tm.nextShape = line;
          tm.nextShape.setMoveX(5);
          tm.nextShape.update();
          tm.nextShape.rotate();
          int actualLineL = tm.nextShape.getCoord()[0].length;
          assertEquals("Length is 1", 1, actualLineL);
          int actualLineW = tm.nextShape.getCoord().length;
          assertEquals("Width is 4", 4, actualLineW);
         
    }
    
    @Test
    public void testRotateNotAbleAfterHit() {
    	 Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
         tm.nextShape = zig;
         tm.nextShape.setHit(true);
         tm.nextShape.rotate();
         int actualZigL = tm.nextShape.getCoord()[0].length;
         assertEquals("Length is 3", 3, actualZigL);
         int actualZigW = tm.nextShape.getCoord().length;
         assertEquals("Width is 2", 2, actualZigW);
         
         Shape line = new Shape (tm.getDiffShapes()[0].getBox(), 
          		tm.getDiffShapes()[0].getCoord(), tm);
          tm.nextShape = line;
          tm.nextShape.setHit(true);
          tm.nextShape.rotate();
          int actualLineL = tm.nextShape.getCoord()[0].length;
          assertEquals("Length is 4", 4, actualLineL);
          int actualLineW = tm.nextShape.getCoord().length;
          assertEquals("Width is 1", 1, actualLineW);  
    }
    
    @Test
    public void testRotateAgainstShape() {
    	for (int i = 4; i < tm.getCourt().length; i++) {
    		for (int j = 3; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	Shape line = new Shape (tm.getDiffShapes()[0].getBox(), 
         		tm.getDiffShapes()[0].getCoord(), tm);
         tm.nextShape = line;
         tm.nextShape.rotate();
         tm.nextShape.update();
         tm.nextShape.rotate(); //shouldn't rotate
         int actualLineL = tm.nextShape.getCoord()[0].length;
         assertEquals("Length is 1", 1, actualLineL);
         int actualLineW = tm.nextShape.getCoord().length;
         assertEquals("Width is 4", 4, actualLineW);  
    }
    
    @Test
    public void testGameOver() {
    	for (int i = 0; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	tm.gameOver();
    	assertTrue("Game Over when full", tm.getGameOver());
    }
    
    @Test
    public void testNotGameOver() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	tm.gameOver();
    	assertFalse("Not Game over yet, top line not filled", tm.getGameOver());
    }
    
    @Test
    public void testGameOverAfterNext() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
        tm.makeNew();
        tm.nextShape.update();
        tm.nextShape.update();
    	tm.gameOver();
    	assertTrue("Game Over after top line is fillled", tm.getGameOver());
    }
    
    @Test
    public void testNotGameOverAfterUndo() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	tm.addMoves();
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
        tm.nextShape.update();
    	tm.setCourt(tm.getMove().delMove());
    	tm.gameOver();
    	assertFalse("Not Game Over after top line is undone", tm.getGameOver());
    }
    
    @Test
    public void testNotClearLine() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
        tm.nextShape.update();
        tm.nextShape.update(); //twice to bring the shape down, then gameOver
    	tm.gameOver();
        tm.nextShape.check();
        assertTrue("No lines are erased, game is over", tm.getGameOver());
    }
    
    @Test
    public void testClearLine() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
        tm.nextShape.check();
        assertFalse("No lines are erased, game is over", tm.getGameOver());
    }
    
    @Test 
    public void testUndo(){
    	
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	tm.addMoves();
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
        tm.nextShape.update();
        tm.addMoves();
    	tm.setCourt(tm.getMove().delMove());
    	tm.gameOver();
    	assertFalse("No lines are erased, game is over", tm.getGameOver());
    }
    
    @Test (expected = IndexOutOfBoundsException.class) 
    public void testUndoError(){
    	
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
    	tm.setCourt(tm.getMove().delMove());
    	tm.gameOver();
    }
    
    @Test (expected = IndexOutOfBoundsException.class) 
    public void testUndoPastLastMove() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	//Delete three moves, only two in there, should fail
    	tm.addMoves();
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
        tm.nextShape.update();
        tm.addMoves();
    	tm.setCourt(tm.getMove().delMove());
    	tm.setCourt(tm.getMove().delMove()); 
    	tm.setCourt(tm.getMove().delMove()); 
    	tm.gameOver();
    } 
    
    @Test
    public void testOneHighScoreStraight() {
		tm.highS.addUserStraight(new User ("Sam", 4000));
    	User a = tm.highS.getFirst();
    	assertEquals("Highest score is Sam", new User ("Sam", 4000), a);
    }
    
    @Test
    public void testTwoHighScoresStraight() {
		tm.highS.addUserStraight(new User ("Sam", 4000));
		tm.highS.addUserStraight(new User ("Bob", 200));
    	User a = tm.highS.getFirst();
    	User b = tm.highS.getSecond();
    	assertEquals("Highest score is Sam", new User ("Sam", 4000), a);
    	assertEquals("Next highest score is Bob", new User ("Bob", 200), b);
    }
    
    @Test
    public void testFileHighScore() {
    	try {
			tm.highS.highScore(); //use output.txt
		} catch (IOException e) {
		}
    	User a = tm.highS.getFirst();
    	User b = tm.highS.getSecond();
    	assertEquals("Highest score is Sam", new User ("Sam", 4000), a);
    	assertEquals("Next highest score is Bobby", new User ("Bobby", 2000), b);
    } 
    
    @Test
    public void testAddUserToFile() {
    	PrintWriter writer; //clear file
		try {
			writer = new PrintWriter(new File ("testFile.txt"));
	    	writer.print("");
	    	writer.close();
		} catch (FileNotFoundException e1) {
		}
    	tm.highS.inpToFile(new User("Sam", 4000), "testFile.txt");
    	try {
			tm.highS.outputHigh(new File ("testFile.txt"));
		} catch (IOException e) {
		}
    	User a = tm.highS.getFirst();
    	assertEquals("Highest score is Sam", new User ("Sam", 4000), a);
    } 
    
    @Test
    public void testAddMultUserToFile() {
    	PrintWriter writer; //clear file
		try {
			writer = new PrintWriter(new File ("testFile.txt"));
	    	writer.print("");
	    	writer.close();
		} catch (FileNotFoundException e1) {
		}
    	tm.highS.inpToFile(new User("Sam", 4000), "testFile.txt");
    	tm.highS.inpToFile(new User("Bob", 40000), "testFile.txt");
    	try {
			tm.highS.outputHigh(new File ("testFile.txt"));
		} catch (IOException e) {
		}
    	User a = tm.highS.getFirst();
    	User b = tm.highS.getSecond();
       	assertEquals("Highest score is Bob", new User ("Bob", 40000), a);
    	assertEquals("Highest score is Sam", new User ("Sam", 4000), b);
    } 
    
    @Test
    public void testUsernameHasNumbers() {
    	PrintWriter writer; //clear file
		try {
			writer = new PrintWriter(new File ("testFile.txt"));
	    	writer.print("");
	    	writer.close();
		} catch (FileNotFoundException e1) {
		}
    	tm.highS.inpToFile(new User("Sam09", 4000), "testFile.txt");
    	tm.highS.inpToFile(new User("B5o1b", 40000), "testFile.txt");
    	try {
			tm.highS.outputHigh(new File ("testFile.txt"));
		} catch (IOException e) {
		}
    	User a = tm.highS.getFirst();
    	User b = tm.highS.getSecond();
       	assertEquals("Highest score is Bob", new User ("Bob", 40000), a);
    	assertEquals("Highest score is Sam", new User ("Sam", 4000), b);
    } 
    
    
    @Test
    public void testIfHit() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig;
        tm.nextShape.update();
        assertTrue("Block hits the exisiting blocks", tm.nextShape.isHit());
    }
    
    @Test
    public void testIfNotHit() {
    	for (int i = 1; i < tm.getCourt().length; i++) {
    		for (int j = 0; j < tm.getCourt()[0].length - 1; j++) {
    	    	tm.getCourt()[i][j] = 1;
    		}
    	}
    	Shape zig = new Shape (tm.getDiffShapes()[1].getBox(), 
         		tm.getDiffShapes()[1].getCoord(), tm);
        tm.nextShape = zig; //not updated
        assertFalse("Block hits the exisiting blocks", tm.nextShape.isHit());
    }
}
