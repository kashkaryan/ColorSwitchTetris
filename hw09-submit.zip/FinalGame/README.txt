=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=
CIS 120 Game Project README
PennKey: kachik
=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=:=

===================
=: Core Concepts :=
===================

- List the four core concepts, the features they implement, and why each feature
  is an appropriate use of the concept. Incorporate the feedback you got after
  submitting your proposal.

  1. I used 2-D arrays to model the map and the different shapes that drop. This 
  is appropriate because Tetris naturally uses a grid format to model where the 
  shapes currently are. The uses of a 2D array in this context is easily being able 
  to move a shape left, right, and down by one grid value. Also, when I rotate a 
  shape, it is easier to imagine a 2D array rotating rather than a new object. Also,
  when I am making the different shapes, it is easy to imagine what the shape should
  look like when I use 1's to represent a filled square and 0's to represent empty 
  squares in each shapes 2D array.

  2. I used collections in a Moves object that stores the map after each turn. I 
  gave the player the option to press the space bar to go back to the previous 
  move. Collection is a good option for the undo button because I can store the 
  moves as a list, and I can easily add a new move and remove the last grid using
  built in functions from the list library. I then set the court to the latest 
  one in the list after removing the list.

  3. For File I/O, I used it in my incorporation of the high scores list. To
  represent high scores, I used a linked list that after adding users that have a
  name and a score, sort the users by highest score. The current player has a score, 
  and after they lose, they are asked to input their name. Their name gets stored in
  a text file, which takes care of the input part of I/O. I used a buffered writer 
  to write in the text file. This is helpful because I can print it in an easily
  accessible way for the output part later on. Then, my HighScores class uses a
  buffered reader to create new Users it reads from the file, add them to a 
  collection of Users sorted by score, and print the top 5 scores with their names
  when the high scores button is pressed. I/O is useful here because I am able to
  easily read in the text file line by line and check if the added characters are
  letters or digits, and use that to add each line as a user.
 
  4. I made the game testable, taking advantage of the 2D array's I used to
  represent the map and the shapes. I tested if each of the shapes printed as they
  should, and if the dimensions flip when I rotated the shape. To test edge cases
  for the rotate function. I wanted to make sure you could not rotate the shape
  after it has hit the shapes in the map, when it's on the side of a map, and when
  it's against a wall of shapes already set on the map. To test undo, I added new
  shapes, added those shapes to my list of moves, used undo, then asked if the 
  game was gameOver. If undo was not functional, I would get that the game would 
  be over when it shouldn't be. Also, I tested if I get an IndexOutOfBounds exception
  when I try to undo past the first move. I also check that the update function works
  by colliding a shape to the existing map, and after updating, asking if it's
  hit variable is true or not. Finally, I added Users to files and extracted Users
  to make sure that the HighScores class is operating properly and sorting
  Users in my desired order. This is an appropriate use of the concept because I 
  am checking the main state of the game as well as the functionality of all the 
  moving parts indicative of a properly working Tetris.


=========================
=: Your Implementation :=
=========================

- Provide an overview of each of the classes in your code, and what their
  function is in the overall game.
  
  From top to bottom, the first class is my HighScores class. I use this to keep
  a list of the Users. I also use this class for my implementation of I/O, by 
  outputting all the Users in the collection to a file, and using the names and 
  the scores in the file to output a top 5 list. 
  
  The MainTetris class is where the court is, as well as variables that allude to 
  the Move class and the High Score class. This class has a timer that drops 
  a shape after an interval I input manually, it handles the keys pressed by the 
  user, and the different shapes that could be dropped. Using the different shapes
  I define in this class, I make a new shape, stop the game if the court is full,
  get the name of the player, paint the map, and handle the users request to make
  a new game.
  
  The Game is the interface the user interacts with. I heavily used the Swing
  library in this class to make the frame where the game is going to be displayed,
  the buttons for a new game, the instructions, and high scores. 
  
  Moves holds a list of the courts after each "move" or after a shape is placed down,
  and using different functions adds and removes a set to go back one step at the 
  press of the space bar. 
  
  The Shape class is where I handle the updating of the blocks. The block is dropped
  after a certain length of time, and if the down button is pressed, the interval is 
  shortened. If the shape is against an object, I make the shapes lateral movement
  true, meaning it can't move left or right, and also if the shape touches a shape 
  that is set, that shape becomes set with the hit variable. I handle the shape's
  draw function by using a filled rectangle, and the color of the next shape to make
  the entire map's color change. I also handle the rotate function of the shapes here,
  along with the edge cases, the ability for a shape to check if a line is 
  filled, and clear it while moving the existing map down. Finally, I added a function
  that speeds up the dropping of a shape depending on the score of the user.
  
  I used a simple SingleSq class to keep track of the color of a shape as well as 
  the function to draw each block of the shape.
  
  In User, I represent each time a player plays as an object with a nickname and 
  an identity which in this case is its score. I define the compareTo function 
  for the HighScores function to sort out the Users. 


- Were there any significant stumbling blocks while you were implementing your
  game (related to your design, or otherwise)?

	I had a difficult time setting my court to move with the timer function from mushroom 
	of doom, making the map focusable for key inputs, represeinting shapes, and 
	most of all figuring out how to drop shapes on top of each other and to neglect 
	the 0's in the shapes array. The drawing was also a bit difficult, but after 
	mapping out what I want it to draw at what point, I got a clear idea of how
	to incorporate it with updating the map.

- Evaluate your design. Is there a good separation of functionality? How well is
  private state encapsulated? What would you refactor, if given the chance?
  
  I appropriately separated the window the users interact with with the game. 
  The user, from the Game class is only able to play the game and press 
  buttons. Also, because after the game the User can only use letters in their
  name, they can not manipulate their score by including a number at the end of
  their name. My User object maintains separate functionality from the HighScores
  class, and the High Score variable that is called by the game can not be
  manipulated by the user. In the MainTetris class, I made all the variables 
  in the constructor private except for the high score and the next shape. I 
  did this to be able to access it and alter it when I test it in GameTest.
  Although this isn't perfectly encapsulated, I believe the user is not able
  to alter the state of the tetris main object to break encapsulation. I separate 
  functionality clearly in the Moves class from MainTetris, and SingleSq from 
  Shape. However, I could improve on separating MainTetris and Shape. I could have
  made the different shapes in the Shape class, as well as clearing lines in the 
  MainTetris class instead of the Shape class. My thought process was to include
  anything involving an individual shape in the shape class and anything involving 
  multiple shapes in the MainTetris class.


========================
=: External Resources :=
========================

- Cite any external resources (libraries, images, tutorials, etc.) that you may
  have used while implementing your game.
  
  I used a buffered writer library I added to write the names of users into 
  a file, as well as a file library be able to use the buffered writer. And I used 
  a linked list, an iterator collection, and a scanner to read in lines from the 
  file. I used key listeners and action listeners similar to Mushroom of Doom in 
  the MainTetris class. For the Game, I did not use outside libraries, but
  I looked at some Swing tutorials from Youtube I linked below. The tutorial 
  also gave some basis on html and how to use it to write the instruction. Besides 
  that, I saw images of shapes online of the tetris shapes, and how they look when 
  they are rotated counter-clockwise. I also used the Color library in fillRect.
  Part of the tutorial on swing, I learned how to use System.currentTimeMillis()
  to keep track of the time of the system, as well as from the system oracle page.
  
  https://docs.oracle.com/javase/7/docs/api/java/io/BufferedWriter.html
  https://docs.oracle.com/javase/7/docs/api/java/io/File.html
  https://docs.oracle.com/javase/7/docs/api/java/util/Scanner.html
  https://www.youtube.com/watch?v=jUEOWVjnIR8
  https://docs.oracle.com/javase/7/docs/api/java/lang/System.html
  
  
